import { Link } from "react-router-dom";
import "./Movie.css";

function Movie({ title, posterUrl, movieId }) {
   return (
      <Link className="movie-container" to={`/movies/${movieId}`}>
         <img className="movie-poster" src={posterUrl} alt={`Poster of ${title}`} />
         <h2 className="title">{title}</h2>
         <span className="backdropBg"></span>
      </Link>
   );
}

export default Movie;
