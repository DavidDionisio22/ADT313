import NavigationBar from "../../components/Navigation/Navigation";
import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import "./MovieInfo.css";
import Cast from "./Cast";
import Video from "./Video";

function MovieInfo() {
   const [movie, setMovie] = useState([]);
   let { id } = useParams();

   useEffect(() => {
      const fetchMovie = async () => {
         if (id) {
            const res = await axios.get(`/movies/${id}`);
            setMovie(res.data);
         }
      };

      fetchMovie();
   }, []);

   function formatDate(dateStr) {
      const date = new Date(dateStr);
      const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      return `${months[date.getMonth()]} ${date.getDate()}, ${date.getFullYear()}`;
   }

   return (
      <main>
         <NavigationBar />

         <section className="info-container">
            <img className="info-backdrop" src={movie.backdropPath} alt="" />
            <span className="info-backdropBg"></span>
            <div className="info-poster">
               <img src={movie.posterPath} alt="" />
            </div>
            <div className="info-content">
               <h1 className="title">{movie.title}</h1>
               <p className="overview">{movie.overview}</p>
               <p className="release-date">Release Date: {formatDate(movie.releaseDate)}</p>
               <p className="popularity">Popularity: {parseFloat(movie.popularity)}</p>
               <p className="vote-average">Vote Average: {parseFloat(movie.voteAverage)}</p>
               <button className="watch">
                  Watch Movie
                  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16">
                     <path d="m11.596 8.697-6.363 3.692c-.54.313-1.233-.066-1.233-.697V4.308c0-.63.692-1.01 1.233-.696l6.363 3.692a.802.802 0 0 1 0 1.393" />
                  </svg>
               </button>
            </div>
         </section>

         {movie.casts && Array.isArray(movie.casts) && (
            <section className="details-container">
               <h1>Casts</h1>
               <div className="details-wrapper">
                  {movie.casts.map((cast) => (
                     <Cast key={cast.id} name={cast.name} image={cast.url} characterName={cast.characterName} />
                  ))}
               </div>
            </section>
         )}

         {movie.photos && Array.isArray(movie.photos) && (
            <section className="details-container">
               <h1>Photos</h1>
               <div className="details-wrapper">
                  {movie.photos.map((photo) => (
                     <img key={photo.id} src={photo.url} width={"480px"} height={"300px"} />
                  ))}
               </div>
            </section>
         )}

         {movie.videos && Array.isArray(movie.videos) && (
            <section className="details-container">
               <h1>Videos</h1>
               <div className="video-wrapper">
                  {movie.videos.map((video) => (
                     <Video key={video.id} videoUrl={video.url} title={video.name} />
                  ))}
               </div>
            </section>
         )}
      </main>
   );
}

export default MovieInfo;
