import "./Cast.css";

function Cast({ name, image, characterName }) {
   return (
      <section className="cast-parent">
         <img className="cast-image" src={image} alt={`Poster of ${name}`} />
         <h2 className="cast-name">{characterName}</h2>
         <p className="cast-stage">{name}</p>
      </section>
   );
}

export default Cast;
