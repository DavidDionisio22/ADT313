import "./Video.css";

function Video({ videoUrl, title }) {
   return (
      <section className="video-parent">
         {/* Embed YouTube Video */}
         <div className="video-container">
            <iframe
               width="400px"
               height="315"
               src={videoUrl}
               title={title}
               allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
               allowFullScreen
            ></iframe>
         </div>
         <h2 className="video-name">{title}</h2>
      </section>
   );
}

export default Video;
