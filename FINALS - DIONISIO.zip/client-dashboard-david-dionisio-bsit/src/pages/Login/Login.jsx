import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Login.css";
import axios from "axios";
import { useUserContext } from "../../UserContext";

function Login() {
   const [email, setEmail] = useState("");
   const [password, setPassword] = useState("");
   const [error, setError] = useState("");

   const navigate = useNavigate();
   const { login } = useUserContext();

   const handleLogin = async () => {
      setError("");

      if (email && password) {
         const data = { email, password };

         await axios({
            method: "post",
            url: "/user/login",
            data,
            headers: { "Access-Control-Allow-Origin": "*" },
         })
            .then((res) => {
               const userData = {
                  id: res.data.user.userId,
                  email: res.data.user.email,
                  firstName: res.data.user.firstName,
                  lastName: res.data.user.lastName,
                  role: res.data.user.role,
                  accessToken: res.data.access_token,
               };

               login(userData);
               navigate("/dashboard");
            })
            .catch((e) => {
               setError(e.response.data.message);
            });
      } else {
         setError("Complete the fields then try again.");
      }
   };

   return (
      <div className="login-container">
         <span className="login-backdrop"></span>
         <img className="background-movies" src="background.png" alt="" />
         <div className="login-wrapper">
            <h1 className="login-title">Login</h1>
            <input
               className="login-input input-email"
               type="email"
               placeholder="Enter email address here"
               onChange={(e) => {
                  setEmail(e.target.value);
               }}
            />
            <input
               className="login-input input-password"
               type="password"
               placeholder="Enter password here"
               onChange={(e) => {
                  setPassword(e.target.value);
               }}
            />
            <button className="login-submit" onClick={handleLogin}>
               Sign In
            </button>
            {error && <p className="error">{error}</p>}
            <span className="link">
               <Link to="/register">Don't have an account? Click here to register.</Link>
            </span>
         </div>
      </div>
   );
}

export default Login;
