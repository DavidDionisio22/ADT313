import { useState, useRef, useCallback, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Dashboard.css";
import NavigationBar from "../../components/Navigation/Navigation";
import axios from "axios";
import Movie from "../../components/Movie/Movie";

function Dashboard() {
   const [movies, setMovies] = useState([]);

   useEffect(() => {
      const fetchMovies = async () => {
         try {
            const res = await axios.get("/movies");
            setMovies(res.data);
         } catch (error) {
            console.error(error);
         }
      };

      fetchMovies();
   }, []);

   const randomNum = Math.floor(Math.random() * movies.length);

   return (
      <div className="container">
         <NavigationBar />
         {movies.length > 0 && (
            <div className="backgroup-container">
               <img className="backdrop" src={movies[randomNum].backdropPath} alt="Backdrop" />
               <span className="backdropBg"></span>
               <section className="label-container">
                  <h1 className="title">{movies[randomNum].title}</h1>
                  <p className="overview">{movies[randomNum].overview}</p>
                  <Link to={`/movies/${movies[randomNum].id}`} className="more-info">
                     More info
                     <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="white" viewBox="0 0 16 16">
                        <path
                           fillRule="evenodd"
                           d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8"
                        />
                     </svg>
                  </Link>
               </section>
            </div>
         )}
         {movies.length > 0 && (
            <section className="list-container">
               <h1 className="title">All Movies</h1>
               <div className="list-wrapper">
                  {movies.map((movie) => (
                     <Movie key={movie.id} title={movie.title} posterUrl={movie.posterPath} movieId={movie.id} />
                  ))}
               </div>
            </section>
         )}
      </div>
   );
}

export default Dashboard;
