import * as React from "react";
import * as ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import "./index.css";
import Login from "./pages/Login/Login";
import Registration from "./pages/Registration/Registration";

const router = createBrowserRouter([
   {
      path: "/",
      element: <Login />,
   },
   {
      path: "/register",
      element: <Registration />,
   },
]);

function App() {
   return (
      <div className="App">
         <RouterProvider router={router} />
      </div>
   );
}

export default App;
