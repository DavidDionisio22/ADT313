import { useState, useRef, useCallback, useEffect } from "react";
import "./Registration.css";
import axios from "axios";

function Registration() {
   const [email, setEmail] = useState("");
   const [password, setPassword] = useState("");

   const handleOnChange = (event, type) => {};

   const handleLogin = async () => {
      const data = { email, password };
		
      await axios({
         method: "post",
         url: "/admin/login",
         data,
         headers: { "Access-Control-Allow-Origin": "*" },
      })
   };

   return (
      <div className="container">
			<div className="wrapper">
				<h1 className="title">Login</h1>
				<input className="input input-login" type="text" placeholder="Enter email address here" />
				<input className="input input-password" type="password" placeholder="Enter password here" />
				<button className="submit">Sign In</button>
				
			</div>
		</div>
   );
}

export default Registration;
