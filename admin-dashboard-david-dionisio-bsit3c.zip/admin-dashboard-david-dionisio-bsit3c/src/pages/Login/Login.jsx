import { useState, useRef, useCallback, useEffect } from "react";
import { Link } from "react-router-dom";
import "./Login.css";
import axios from "axios";

function Login() {
   const [email, setEmail] = useState("");
   const [password, setPassword] = useState("");

   const handleLogin = async () => {
      if (email && password) {
         const data = { email, password };
         console.log(data);

         axios({
            method: "post",
            url: "/admin/login",
            data,
            headers: { "Access-Control-Allow-Origin": "*" },
         })
            .then((res) => {
               console.log(res.data.access_token);
               localStorage.setItem("accessToken", res.data.access_token);
            })
            .catch((e) => {
               console.log(e.response.data.message);
            });
      }
   };

   return (
      <div className="container">
         <div className="wrapper">
            <h1 className="title">Login</h1>
            <input
               className="input input-login"
               type="text"
               placeholder="Enter email address here"
               onChange={(e) => {
                  setEmail(e.target.value);
               }}
            />
            <input
               className="input input-password"
               type="password"
               placeholder="Enter password here"
               onChange={(e) => {
                  setPassword(e.target.value);
               }}
            />
            <button className="submit" onClick={handleLogin}>
               Sign In
            </button>
            <span className="link">
               <Link to="/register">Don't have an account? Click here to register.</Link>
            </span>
         </div>
      </div>
   );
}

export default Login;
