import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Login from "./pages/Login/Login";
import Registration from "./pages/Registration/Registration";
import Dashboard from "./pages/Dashboard/Dashboard";
import MovieInfo from "./pages/Movies/MovieInfo";
import { UserProvider } from "./UserContext";

const router = createBrowserRouter([
   {
      path: "/",
      element: <Login />,
   },
   {
      path: "/register",
      element: <Registration />,
   },
   {
      path: "/dashboard",
      element: <Dashboard />,
   },
   {
      path: "/movies/:id",
      element: <MovieInfo />,
   },
]);

function App() {
   return (
      <div className="App">
         <UserProvider>
            <RouterProvider router={router} />
         </UserProvider>
      </div>
   );
}

export default App;
