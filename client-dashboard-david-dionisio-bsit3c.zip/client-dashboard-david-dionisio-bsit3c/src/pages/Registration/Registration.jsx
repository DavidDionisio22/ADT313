import { useState, useRef, useCallback, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Registration.css";
import axios from "axios";

function Registration() {
   const [firstName, setFirstName] = useState("");
   const [middleName, setMiddleName] = useState("");
   const [lastName, setLastName] = useState("");
   const [contactNo, setPhoneNumber] = useState("");
   const [email, setEmail] = useState("");
   const [password, setPassword] = useState("");
   const [error, setError] = useState("");
   const [success, setSuccess] = useState("");
   const navigate = useNavigate();

   const handleRegister = async () => {
      const data = { email, password, firstName, middleName, lastName, contactNo };

      await axios({
         method: "post",
         url: "/user/register",
         data,
         headers: { "Access-Control-Allow-Origin": "*" },
      })
         .then((res) => {
            setSuccess(res.message);
            navigate("/");
         })
         .catch((e) => {
            setError(e.response.data.message);
         });
   };

   return (
      <div className="register-container">
         <span className="register-backdrop"></span>
         <img className="background-movies" src="background.png" alt="" />
         <div className="register-wrapper">
            <h1 className="register-title">Register</h1>
            <input
               className="input input-login"
               type="text"
               placeholder="Enter first name here"
               onChange={(e) => {
                  setFirstName(e.target.value);
               }}
            />
            <input
               className="input input-login"
               type="text"
               placeholder="Enter middle name here"
               onChange={(e) => {
                  setMiddleName(e.target.value);
               }}
            />
            <input
               className="input input-login"
               type="text"
               placeholder="Enter last name here"
               onChange={(e) => {
                  setLastName(e.target.value);
               }}
            />
            <input
               className="input input-login"
               type="text"
               placeholder="Enter email address here"
               onChange={(e) => {
                  setEmail(e.target.value);
               }}
            />
            <input
               className="input input-login"
               type="text"
               placeholder="Enter contact number here"
               onChange={(e) => {
                  setPhoneNumber(e.target.value);
               }}
            />
            <input
               className="input input-password"
               type="password"
               placeholder="Enter password here"
               onChange={(e) => {
                  setPassword(e.target.value);
               }}
            />
            <button className="submit" onClick={handleRegister}>
               Sign In
            </button>
            {error && <p className="error">{error}</p>}
            {success && <p className="success">{success}</p>}
            <span className="link">
               <Link to="/">Already have an account? Click here to login.</Link>
            </span>
         </div>
      </div>
   );
}

export default Registration;
